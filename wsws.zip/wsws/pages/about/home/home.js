Component({
  options: {
    addGlobalClass: true,
  },
  data: {
    starCount: 0,
    forksCount: 0,
    visitTotal: 0,
  },
  attached() {
    console.log("success")
    let that = this;
    wx.showLoading({
      title: '数据加载中',
      mask: true,
    })
    let i = 0;
    numDH();
    function numDH() {
      if (i < 20) {
        setTimeout(function () {
          that.setData({
            starCount: i,
            forksCount: i,
            visitTotal: i
          })
          i++
          numDH();
        }, 20)
      } else {
        that.setData({
          starCount: that.coutNum(3620),
          forksCount: that.coutNum(484),
          visitTotal: that.coutNum(4053)
        })
      }
    }
    wx.hideLoading()
  },
  methods: {
    coutNum(e) {
      if (e > 1000 && e < 10000) {
        e = (e / 1000).toFixed(1) + 'k'
      }
      if (e > 10000) {
        e = (e / 10000).toFixed(1) + 'W'
      }
      return e
    },
    CopyLink(e) {
      wx.setClipboardData({
        data: e.currentTarget.dataset.link,
        success: res => {
          wx.showToast({
            title: '已复制',
            duration: 1000,
          })
        }
      })
    },
    showModal(e) {
      this.setData({
        modalName: e.currentTarget.dataset.target
      })
    },
    hideModal(e) {
      this.setData({
        modalName: null
      })
    },
    showQrcode() {
      wx.previewImage({
        urls: ['https://gitee.com/kingrise/codes/ks1ljbhnox6zd0348yf7533/raw?blob_name=%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190815140151.png'],
        current: 'https://gitee.com/kingrise/codes/ks1ljbhnox6zd0348yf7533/raw?blob_name=%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190815140151.png' // 当前显示图片的http链接      
      })
    },
  }
})