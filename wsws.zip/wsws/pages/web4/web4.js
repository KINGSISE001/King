const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    list:[]
  },
  onShareAppMessage: function (res) {
    let users = wx.getStorageSync('user');
    if (res.from === 'button') { }
    return {
      title: '流量卡',
      path: '/pages/web4/web4',
      success: function (res) { }
    }
  },
  onLoad: function() {

    var that = this //不要漏了这句，很重要
    wx.request({
      url: 'https://gitee.com/kingrise/codes/kwbjnq7lvcahf6o9sgm1i92/raw?blob_name=ka',
      headers: {
        'Content-Type': 'application/json'
      },
      success: function(res) {
        that.setData({
          list: res.data.list,
          tongzhi: res.data.tongzhi,
          card: res.data.card
        })
      }
    })

    var random1 = Math.floor(Math.random() * 2000 + 1000);
    var random2 = Math.floor(Math.random() * 2000);
    var random3 = Math.floor(Math.random() * 20);
    this.setData({
      suiji1: random1,
      suiji2: random2,
      suiji3: random3
    })
  },
  isCard(e) {
    this.setData({
      isCard: e.detail.value,
    })
  },
  previewImage: function(e) {
    var current = e.target.dataset.src;
    var list1=[e.target.dataset.list];
    wx.previewImage({
      current: current, // 当前显示图片的http链接  
      urls:list1, // 需要预览的图片http链接列表   
    })
  }
});