var app = getApp();
var util = require('../../utils/util.js');
Page({
  /**
  * 页面的初始数据
  */
  data: {
    inputValue: '渣女', //搜索的内容
    CustomBar: app.globalData.CustomBar,
    StatusBar: app.globalData.StatusBar,
  },

  showModal(e) {

    var that = this;
    that.setData({
      modalName: e.currentTarget.dataset.target,
      name: e.currentTarget.dataset.name,
      explain: e.currentTarget.dataset.explain
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  onShareAppMessage: function (res) {
    let users = wx.getStorageSync('user');
    if (res.from === 'button') { }
    return {
      title: '垃圾分类查询',
      path: '/pages/web1/web1',
      success: function (res) { }
    }
  },
  //搜索框文本内容显示
  inputBind: function (event) {
    this.setData({
      inputValue: event.detail.value
    })
  },
  /**
  * 搜索执行按钮
  */
  query: function (event) {
    var that = this
    /**
     * 提问帖子搜索API
     * keyword string 搜索关键词 ; 这里是 this.data.inputValue
     * start int 分页起始值 ; 这里是 0
     */
    wx.request({
      url: 'https://api.tianapi.com/txapi/lajifenlei/',
      data: {
        word: this.data.inputValue,
        key:'d1225511d7e629fd8dd482613723513c',
      },
      method: 'GET',
      success: function (res) {
        console.log(res.data)
        var searchData = res.data.newslist
        var search = res.data.code
        that.setData({
          searchData,
          search
        })
        /**
         * 设置 模糊搜索
         */
        if (!that.data.inputValue) {
          //没有搜索词 友情提示
          wx.showToast({
            title: '请重新输入哦！',
            image: '../../images/11.png',
            duration: 2000,
          })
        } else if (search == 250) {
          //搜索词不存在 友情提示
          wx.showToast({
            title: '我也不知道哦！',
            image: '../../images/11.png',
            duration: 2000,
          })
        } 
      }
    })
  }
})